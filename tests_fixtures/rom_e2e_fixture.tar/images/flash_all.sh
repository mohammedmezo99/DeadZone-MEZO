#!/usr/bin/env bash
# Fastboot script for redminote12pro
set -e
fastboot erase boot
fastboot flash boot boot.img
fastboot flash system system.img
fastboot flash vendor vendor.img
fastboot flash super super.img
fastboot set_active a
fastboot reboot-bootloader
fastboot reboot
